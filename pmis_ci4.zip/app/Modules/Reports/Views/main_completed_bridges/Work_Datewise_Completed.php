<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
					<div class="col-lg-12">
						<p class="reportHeader center" >Work Progress</p>
                        <p class="reportHeader center" >Project Status:Commited Bridges</p>
						<div class=" table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th style="width:36px;" class="center" rowspan="2" >SN</th>
                                        <th style="width:288px;" class="center" colspan="4">Bridge</th>
                                        <th style="width:288px;" class="center" colspan="2">VDC</th>                                                
                                        <th style="width:72px;" class="center" rowspan="2" >River Name</th>
                                        <th style="width:108px;" class="center" colspan="2">Walk Way Deck</th>
                                        <th style="width:432px;" class="center" colspan="11">ComponentWise Cost in NRs.</th>
                                        <th style="width:72px;" class="center" rowspan="2" >Remarks</th>
                                        
                                    </tr>
                                    <tr>
                                        <th  class="center">Number</th>
                                        <th  class="center">Name</th>
                                        <th  class="center">Type</th>
                                        <th  class="center">Span(m)</th>	
                                        <th  class="center">Left Bank</th>
                                        <th  class="center">Right Bank</th>
                                        <th  class="center">Type**</th>
                                        <th  class="center">Width(cm)</th>	
                                        <th  class="center">Site Assessment And Survey</th>
                                        <th  class="center"> Community Agrement</th>
                                        <th  class="center"> DMBT</th>
                                        <th  class="center"> 1st Phase of construction</th>
                                        <th  class="center"> Materil Supplied to UC</th>
                                        <th  class="center"> 2nd Phase of construction</th>
                                        <th  class="center"> Anchorage Conreating</th>
                                        <th  class="center"> Cable Pulling</th>
                                        <th  class="center"> Bridge Completion</th>
                                        <th  class="center"> BMC Formation</th>
                                        <th  class="center"> Target Completion</th>
                                                                                                                                                                                           	
                                    </tr>
                                </thead>
                            </table>
                        </div>        
                        <div class="col-lg-12 backColor border">
                        	<p class="center boldP lht" >Cancelled Bridges During Fiscal Year: 20102011</p>
                            <p class="center boldP lht">Work Category: Cancelled</p>
                        </div>
                                                                    
                                
                        <!-- 2nd table--> 
                        <div class="col-lg-6"><b><span>District:Dailekh</span></b></div><div class="col-lg-6"><b><span style="float:right;" >TBSU Regional Office:Dhading</span></b></div>
                        <div class="col-lg-6"><b><span>Development Region:&nbsp;</span><span class="bold "> Western</span></b></div>                                   
						<table class="table table-bordered table-hover">
                    	<tr>
                        	<td>1</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        	<td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        	<td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>                                                                                                        
                        </tr>
                    	<tr>
                        	<td>1</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        	<td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        	<td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>                                                                                                        
                        </tr>                                                
                        </table>   									 
                        <!--table3 starts-->
                        <div class="col-lg-6"><b><span>District:Dailekh</span></b></div><div class="col-lg-6"><b><span style="float:right;" >TBSU Regional Office:Dhading</span></b></div>
						<div class="col-lg-6"><b><span>Development Region:&nbsp;</span><span class="bold ">Western</span></b></div>
                		<table class="table table-bordered table-hover">
                        	<tr>
                            	<td>1</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            	<td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            	<td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>                                               
                            </tr>
                        </table>
                        <!--table4starts-->
                        <div class="col-lg-6"><b><span>District:Dailekh</span></b></div><div class="col-lg-6"><b><span style="float:right;" >TBSU Regional Office:Dhading</span></b></div>
						<div class="col-lg-6"><b><span>Development Region:&nbsp;</span><span class="bold ">Western</span></b></div>
						<table class="table table-bordered table-hover">
                        	<tr>
                            	<td>1</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            	<td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            	<td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>                         
                            </tr>
                        </table>
                                    
                        <!---footer-->                                    
                        <div class="col-lg-8"><span>Bridge Type*: </span><span>SD=Suspended-SSTB</span><span> SN=Steel Truss RCC=Rainforced Cement Concrete</span></div>
                        <div class="col-lg-4 right"><span>Bridge Completion During:2/9/2010 To 2/9/2014</span></div>                                 
                        <div class="col-lg-3">2-September-2014</div><div class="col-lg-6 "><span class="center">TBSU Programme Monitoring and Information Systerm PMIS</span></div><div class="col-lg-3 right"><span>Page 1 of 3<span></div>
                        <!---footer-->                                     
					</div>							
				    <div class="clear"></div>
		        </div>
                <!-- /.row -->               
            </div>
            <!-- /.container-fluid -->
        </div>