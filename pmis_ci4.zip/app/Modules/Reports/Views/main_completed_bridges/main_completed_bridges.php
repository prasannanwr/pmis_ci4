 <div class="reportHeader">
        <h1 class="">Completed Bridges Reports</h1>
    </div>

<!--- start third panel---->
<div class="panel panel-red settings-panel">
    <div class="panel-heading">
        <h1 class="panel-title">General Bridge List</h1>
    </div>
    <div class="panel-body">
    <!---start div---->
    <div class="ListSubBridge">
  
                   <div class="panel-body">
         <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Gen_Overall_DateWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Over All<br />Date Wise Report
                    ');?>
                </div>
            </div>
              <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Gen_Overall_FYWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Over All <br />FY Wise Report 
                    ');?>
                </div>
            </div>
              <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Gen_Dist_DateWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    District <br /> Date Wise Report 
                    ');?>
                </div>
            </div>
            
              <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Gen_Dist_FYWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    District <br />FY Wise Report 
                    ');?>
                </div>
            </div>
            
              <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Gen_Dev_DateWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Dev.Region<br />Date Wise Report 
                    ');?>
                </div>
            </div>
            
               <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Gen_Dev_FYWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Dev.Region<br />FY Wise Report 
                    ');?>
                </div>
            </div>
                <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Gen_TBSS_DateWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                   TBSS region <br />data Wise Report 
                    ');?>
                </div>
            </div>
            
            <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Gen_TBSS_FYWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    TBSS region <br />FY Wise Report 
                    ');?>
                </div>
            </div>

                    
               </div>     
                   
                           
            
                                 
            <div class="clear"></div>
        </div>
        
       
        
        <!--- end ---->        
    </div>
</div>

<!--- end third panel---->
<!----- start work progress------>
<div class="panel panel-red settings-panel">
    <div class="panel-heading">
        <h1 class="panel-title">Actual Brigde Cost</h1>
    </div>
    <div class="panel-body">
      <div class="ListSubBridge">
           

             <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Act_Overall_DateWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Over All <br />Date Wise Report 
                    ');?>
                </div>
            </div>
            
            <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Act_Overall_FYWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Over All <br />Fiscal Wise Report 
                    ');?>
                </div>
            </div>
            
            <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Act_Dist_DateWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    District<br /> Date Wise Report 
                    ');?>
                </div>
            </div>
            
            <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Act_Dist_FYWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    District <br />FY Wise Report 
                    ');?>
                </div>
            </div>
            
             <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Act_Dev_DateWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Dev.Region <br />Date Wise Report 
                    ');?>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Act_Dev_FYWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Dev.Region <br />FY Wise Report 
                    ');?>
                </div>
            </div>
             <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Act_TBSS_DateWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    TBSS<br />Date Wise Report 
                    ');?>
                </div>
            </div>
            
              <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Act_TBSS_FYWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    TBSS <br /> FY Wise Report 
                    ');?>
                </div>
            </div>
            
             <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Act_Supporting_AgencyWise_DateWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Supporting Agency<br />Date Wise Report 
                    ');?>
                </div>
            </div>
            
              <div class="col-sm-2">
                <div class="panel panel-green">
                    <?php echo anchor('reports/Act_Supporting_AgencyWise_FYWise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Supporting_Agency <br />FY Report 
                    ');?>
                </div>
            </div>
            
            
       
 
            
                
              
  
                   
   
    </div>
    
</div>
</div>    
<!----- endwork progress------>


<!--- start  Engineering Works panel---->
<div class="panel panel-primary settings-panel">
    <div class="panel-heading">
        <h1 class="panel-title"> Actual Bridge Contribution Commitment </h1>
    </div>
    <div class="panel-body">
 
      
        <div class="col-sm-2">
                <div class="panel panel-red">
                    <?php echo anchor('reports/Act_Con_Overall_datewise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Over All <br />Date Wise Report
                    ');?>
                </div>
            </div>  
        <div class="col-sm-2">
                <div class="panel panel-red">
                    <?php echo anchor('reports/Act_Con_Overall_Fywise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Over All <br /> FY Wise Report 
                    ');?>
                </div>
            </div>                       
        <div class="col-sm-2">
                <div class="panel panel-red">
                    <?php echo anchor('reports/Act_Con_Districtwise_datewise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    District <br />Date Wise Report 
                    ');?>
                </div>
            </div>                       
        <div class="col-sm-2">
                <div class="panel panel-red">
                    <?php echo anchor('reports/Act_Con_Districtwise_FYwise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    District <br />FY Wise Report 
                    ');?>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="panel panel-red">
                    <?php echo anchor('reports/Act_Con_Dev_RegionWise_datewise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                     Dev. Region<br />Date Wise Report 
                    ');?>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="panel panel-red">
                    <?php echo anchor('reports/Act_Con_Dev_RegionWise_fywise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Dev. Region <br />FY Wise Report 
                    ');?>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="panel panel-red">
                    <?php echo anchor('reports/Act_Con_TBSSPRegionWise_datewise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    TBSSP Region<br />Date Wise Report 
                    ');?>
                </div>
            </div>                       
           <div class="col-sm-2">
                <div class="panel panel-red">
                    <?php echo anchor('reports/Act_Con_TBSSPRegionWise_FYwise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    TBSSP Region<br />FY Wise Report 
                    ');?>
                </div>
            </div>                       
           <div class="col-sm-2">
                <div class="panel panel-red">
                    <?php echo anchor('reports/Act_Con_Supporting_AgencyWise_datewise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Supporting Agency <br />Date Wise Report 
                    ');?>
                </div>
            </div>                       
           <div class="col-sm-2">
                <div class="panel panel-red">
                    <?php echo anchor('reports/Act_Con_Supporting_AgencyWise_FYwise', '
                    <i class="fa fa-comments fa-3x"></i><br />
                    Supporting Agency <br />FY Wise Report 
                    ');?>
                </div>
            </div>                       
  
                   
   
  
    
</div>
</div>


<!--- end  Engineering Works panel---->

