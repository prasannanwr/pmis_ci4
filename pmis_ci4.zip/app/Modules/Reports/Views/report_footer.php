     <div class="clear"></div>
         <div class="footer_border1">
            <div class="col-lg-8"><span>Bridge Type*: </span><span>SD=Suspended</span>&nbsp;<span>SN=Suspension </span>&nbsp;<span>ST=Steel Truss </span>&nbsp;<!--<span> RCC=Rainforced Cement Concrete</span>--></div>
             <div class="col-lg-4 right" style="padding-right: 10px;"><span><b>Reporting Period: <?php echo $startdate; ?> To <?php echo $enddate; ?></b></span></div>  
         </div>  
         <div class="clear"></div>                                
	<div class="col-lg-4 right"></div>   
                <div class="footer_border2">
 		<div class="col-lg-3"><?php echo _day(); ?></div><div class="col-lg-6 "><span class="center">TBSU Programme Monitoring and Information System (PMIS)</span></div><div class="col-lg-3 right"><!--<span>Page 1 of 3<span> --></div>
               </div>