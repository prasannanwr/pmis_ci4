<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    
                </div>
                <!-- /.row -->
				<div class="row">
					<div class="col-lg-12 mainBoard">
						
							<div class="col-lg-12">
								<span class="reportHeader">Physical Progress Report</span>
								<div class="table-responsive">
									<table class="table table-bordered table-hover">
										<thead>
											<tr>
												<th width="40px" rowspan="2" class="center">SN</th>
												<th width="430px" colspan="3" class="center">Bridge</th>
												<th width="80px" rowspan="2" class="center">Span(m)</th>
												<th width="230px" colspan="2" class="center">Walk Way</th>
												<th width="400px" rowspan="2" class="center">Progress Status</th>
												<th width="" rowspan="2" class="center">Progress in Percentage</th>
											</tr>
											<tr>
												<th width="150px">Number</th>
												<th width="200px">Name</th>
												<th width="80px">Type</th>
												<th width="130px">Type**</th>
												<th width="100px">Width(cm)</th>
											</tr>																		
										</thead>
									</table>
								</div>
							</div>
							
								<div class="col-lg-12"><span>Supporting Agency DRILP</span></div>
								<div class="col-lg-12"><span>District:</span><span>Baglung</span></div>
								<div class="table-responsive col-lg-12">
									<table class="table table-bordered table-hover">	
										<tbody>
											<tr>
												<td width="40px">1</td>												
												<td width="150px">435010180611</td>
												<td width="200px">Tangram khola ghat</td>
												<td width="80px">SD</td>
												<td width="80px">67.00</td>
												<td width="130px">Steel Deck</td>
												<td width="100px">106</td>
												<td width="400px">Site assessment and survey Completed on 29/11/2010</td>
												<td>0%</td>
											</tr>
											<tr>
												<td>1</td>												
												<td>435010180611</td>
												<td>Tangram khola ghat</td>
												<td>SD</td>
												<td>67.00</td>
												<td>Steel Deck</td>
												<td>106</td>
												<td>Site assessment and survey Completed on 29/11/2010</td>
												<td>0%</td>
											</tr>
											<tr>
												<td>1</td>												
												<td>435010180611</td>
												<td>Tangram khola ghat</td>
												<td>SD</td>
												<td>67.00</td>
												<td>Steel Deck</td>
												<td>106</td>
												<td>Site assessment and survey Completed on 29/11/2010</td>
												<td>0%</td>
											</tr>
											<tr>
												<td>1</td>												
												<td>435010180611</td>
												<td>Tangram khola ghat</td>
												<td>SD</td>
												<td>67.00</td>
												<td>Steel Deck</td>
												<td>106</td>
												<td>Site assessment and survey Completed on 29/11/2010</td>
												<td>0%</td>
											</tr>
											<tr>
												<td>1</td>												
												<td>435010180611</td>
												<td>Tangram khola ghat</td>
												<td>SD</td>
												<td>67.00</td>
												<td>Steel Deck</td>
												<td>106</td>
												<td>Site assessment and survey Completed on 29/11/2010</td>
												<td>0%</td>
											</tr>
										</tbody>
									</table>         				                              
								</div>
								<div class="col-lg-12 reportTabHead"><label style="float:right;">Weighted Average of All Bills <span>3.43%</span></label></div>
								<!---footer--> 
								<div class="foot ">
									<label>Bridge Type*:</label>
									<span></span>
									<label>SD:</label>
									<span>Suspended SSTB</span>
									<label>SN:</label>
									<span>Suspension SSTB</span>
									<label>ST:</label>
									<span>Steel Truss</span>
									<label>RCC:</label>
									<span>Re Inforced Cement Concert</span>
                                    <label>Reporting Period(Fiscal Year):</label>
                                    <span>20102011 To 20142015</span>
								</div>	                                   
	         					<div class="">	
								<div class="row">					
									<div class="col-lg-3">
										<span>02-September-2014</span>
									</div>
									<div class="col-lg-6 ">
										<span class="center"> Programme Monitoring and Information System(PMIS)</span>
									</div>
									<div class="col-lg-3 right">
										<span>Page 1 of 1</span>
									</div>
								</div>
								</div>
	        					<!---footer-->     
						
						<div class="clear"></div>
					</div>
				<!--mainboard ends-->		
				</div>
                <!-- /.row -->               
            </div>
            <!-- /.container-fluid -->

        </div>