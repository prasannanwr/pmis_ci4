<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    
                </div>
                <!-- /.row -->
				<div class="row">
					<div class="col-lg-12 mainBoard">
						
							<div class="col-lg-12">
								<span class="reportHeader">Overview:Progress status of New Bridge(s) during FY</span>
								<div class="table-responsive">
									<table class="table table-bordered table-hover">
										<thead>
											<tr>
												<th width="120px" class="center">Districts</th>
												<th width="130px" class="center">New Commit.Pipeline Bridges</th>
												<th width="130px" class="center">Site Assessment & Survey</th>
												<th width="100px" class="center">Design & Estimate</th>
												<th width="100px" class="center">Community Aggrement</th>
												<th width="100px" class="center">1st Phase of Construction</th>
												<th width="100px" class="center">Materials handover</th>
												<th width="130px" class="center">Bridge Completion in the FY</th>				
												<th width="100px" class="center">YPO New</th>
											</tr>																		
										</thead>
									</table>
								</div>
							</div>
							
								<div class="col-lg-12 reportSubHeader"><span>Funded Through:SWAP</span></div>
								<div class="table-responsive col-lg-12">
									<table class="table table-bordered table-hover">	
										<tbody>
											<tr>
												<td width="120px">Taplejung</td>												
												<td width="130px">0</td>
												<td width="130px">0</td>
												<td width="100px">0</td>
												<td width="100px">0</td>
												<td width="100px">0</td>
												<td width="100px">0</td>
												<td width="130px">0</td>
												<td width="100px">0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td>Taplejung</td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>
											<tr>
												<td><b>Sub Total</b></td>												
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
												<td>0</td>
											</tr>											
										</tbody>
									</table>         				                              
								</div>
								<div class="table-responsive col-lg-12">
									<table class="table table-bordered table-hover">
										<tr>																	
											<td width="120px"><b>Grand Total</b></td>
											<td width="130px">0</td>
											<td width="130px">0</td>
											<td width="100px">0</td>
											<td width="100px">0</td>
											<td width="100px">0</td>
											<td width="100px">0</td>
											<td width="130px">0</td>
											<td width="100px">0</td>
										</tr>
									</table>
								</div>
								<!---footer-->                                    
	         					<div class="">	
								<div class="row">					
									<div class="col-lg-3">
										<span>02-September-2014</span>
									</div>
									<div class="col-lg-6 ">
										<span class="center"> Programme Monitoring and Information System(PMIS)</span>
									</div>
									<div class="col-lg-3 right">
										<span>Page 1 of 1</span>
									</div>
								</div>
								</div>
	        					<!---footer-->     
						
						<div class="clear"></div>
					</div>
				<!--mainboard ends-->		
				</div>
                <!-- /.row -->               
            </div>
            <!-- /.container-fluid -->

        </div>